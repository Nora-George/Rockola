const square = document.querySelectorAll('.square');
const Topo = document.querySelectorAll('.Topo');
const score = document.querySelectorAll('#score');
const score_count = document.querySelector('time-left');
let resultado=0;
let posicion;
let timerid=null;
let tiempo=60

function randomsquare() {
    square.forEach(square=>{
        square.classList.remove('Topo')
        });
        let randomsquare = Math.floor(Math.random() * 4);
        randomsquare.classList.add('Topo');
        posicion=randomsquare.id;

}
square.forEach(square=>{
    square.addEventListener('click',()=>{
        if(square.id == posicion){
            resultado++;
            score.textContent=resultado;
            posicion=null;
        }
    });
})
function moveTopo() {
    timerid = setInterval(randomsquare, 500);
}

function tiempores(){
    currentTime --;
    timeleft.textContent=currentTime;
    if(currentTime==0){
        clearInterval(timerid);
        clearInterval(countDowntimerid);
        alert('GAME OVER--PUNTUACION: '+resultado);
    }
}
function Iniciar() {
let countDowntimerid=setInterval(countDown, 1000);
moveTopo();
}


