var ini = document.getElementById('btn');
var facil = document.getElementById('btn2');
var medio = document.getElementById('btn3');
var dificil = document.getElementById('btn4');
var Topo = document.getElementById('topo');
var jugar = false;
var velocidad = 0;
var puntaje=0;
var a;
var X= [0,0,0,150,150,150];
var Y= [0,150,300,0,150,300];
var intervalo;
facil.addEventListener('click', function(){
    if(jugar==false){
        jugar=true;
        velocidad=1400;
    }
})

medio.addEventListener('click', function(){
    if(jugar==false){
        jugar=true;
        velocidad=800;
    }
})

dificil.addEventListener('click', function(){
    if(jugar==false){
        jugar=true;
        velocidad=300;
    }
})

ini.addEventListener('click', function(){
    if(jugar==true){
        setTimeout(() => {
            clearInterval(intervalo);
        }, 30000);
        document.getElementById('topo').style.display="block";
        intervalo=setInterval(() => {
            a=Math.floor(Math.random() * (6 - 1) + 1);
            document.getElementById("topo").style.left=Y[a]+"px";
            document.getElementById("topo").style.top=X[a]+"px";
            document.getElementById("topo").style.display="block";
        }, velocidad);
    }else{
        alert("No has seleccionado una dificultad")
    }
})
Topo.addEventListener('click', function(){
    document.getElementById('topo').style.display="none"
    puntaje=puntaje+25;
    document.getElementById('score').textContent=puntaje;
})
